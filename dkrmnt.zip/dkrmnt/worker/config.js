module.exports = {
   amqpurl:'amqp://rabbitmq'
};
