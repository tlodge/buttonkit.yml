module.exports = {
        redroot: 'http://red:1880',

        flows:'./static/config/flows.local.json',

        mongo:{
                                host:'mongo',
                                port:27017,
                                db:'buttonkit',
        },

        redis:{
                host: 'redis',
                port: 6679,
                pass: 'd54d8e0061e1654b93027567d9ea9c123cd5c82f88144b3d6cf4eecc6ea711df'
        },

        neourl:'http://neo4j:go8tie@neo4j:7474',

        amqpurl:'amqp://rabbitmq',

        mediaroot: '/usr/src/app/static/media',

        oauth:{
                facebook:{
                clientID: '919959334707522',
                clientSecret:'53a60e4ea315a0a3b14f071c7204049f',
                callbackURL:'https://wharfside.buttonkit.com/auth/facebook/callback'
                },

                google:{
                clientID: '1028782195172-mnh9lr1armenio6rq9ot4bj4lkeq2ncr.apps.googleusercontent.com',
                clientSecret:'0w_I93ERxHihxZ5ZthhvDFs0',
                callbackURL:'https://wharfside.buttonkit.com/auth/google/callback'
                }
      },

      email: {
        host: 'postfix',
        port: 25,
        ignoreTLS : true,
        secure : false,
        from: 'me@buttonkit.com'
    },

    twilio: {
        api: 'https://AC90cb13f545ee0d7fd71e55595a0c8b73:0e548a916cbab0c95175afc71f3a9981@api.twilio.com/2010-04-01/Accounts/AC90cb13f545ee0d7fd71e55595a0c8b73/Messages.json',
        from: '+442033224405',
        accountSid: 'AC90cb13f545ee0d7fd71e55595a0c8b73',
        authToken: '0e548a916cbab0c95175afc71f3a9981',
    },
    API_TOKENS : ["AASGFAafafaaFAFaFGA21321392632975632jjHDALH"]
};
