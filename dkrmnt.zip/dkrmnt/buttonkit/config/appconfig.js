module.exports = {

        notify : {

                //send out notification when an action button has been pressed
                "action": {
                        email:  ['tlodge@gmail.com', 'mr.barneylodge@gmail.com'],
                },

                //send out notification when an info button has been pressed
                "info": {

                },

                //send out a notification when a new user has registered
                "register": {
                        email:  ['tlodge@gmail.com'],
                        //sms:  [07972639571],
                },

        }
}
